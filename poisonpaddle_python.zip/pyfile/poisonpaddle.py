from PIL import Image
import ctypes
import pygame
import random
import sys
import random

# Initialisation de Pygame
pygame.init()

# Paramètres de la fenêtre
SCREEN_WIDTH = 360
SCREEN_WIDTHFORBALL=330
SCREEN_HEIGHT = 640
randomme = random.randint(0, 10000000)
if randomme == 1:
    FPS = 30
else :
    FPS = 60

if randomme == 1:
    print(":)")
else: 
    print("game starting...")

# Couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Paramètres de la plateforme
if randomme == 1:
    PLATFORM_WIDTH = 180
else : 
    PLATFORM_WIDTH = 60
PLATFORM_HEIGHT = 20
PLATFORM_MAX_SPEED = 10
PLATFORM_ACCELERATION = 1
PLATFORM_DECELERATION = 0.5
PLATFORM_ROTATION_ANGLE = 5  # 5
MAX_ROTATION_ANGLE = 45 # Angle maximal de rotation

# Paramètres de la balle
BALL_RADIUS = 10
BALL_SPEED_X = 5#5
GRAVITY = 0.5 # 0.5
BOUNCE_SPEED = -23 # -23

# Création de la fenêtre
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("poisonpaddle")
icon_path = "ftg.ico"
icon_pil = Image.open(icon_path)
icon_pil = icon_pil.convert("RGBA")  # Convertir en mode RGBA pour prendre en charge la transparence
icon_pygame = pygame.image.fromstring(icon_pil.tobytes(), icon_pil.size, icon_pil.mode).convert_alpha()
pygame.display.set_icon(icon_pygame)

clock = pygame.time.Clock()

class Platform(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Charger l'image de la plateforme
        platform_image = pygame.image.load("paddle.png").convert_alpha()
        # Redimensionner l'image avec lissage
        self.original_image = pygame.transform.smoothscale(platform_image, (PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.rect = self.original_image.get_rect()
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.bottom = SCREEN_HEIGHT - 90  # Ajustez la position verticale si nécessaire
        self.speed = 0.31415926535897932384626433832795

    def update(self, direction):
        if direction == 1:
            self.speed += PLATFORM_ACCELERATION
        elif direction == -1:
            self.speed -= PLATFORM_ACCELERATION
        else:
            if self.speed > 0:
                self.speed -= PLATFORM_DECELERATION
            elif self.speed < 0:
                self.speed += PLATFORM_DECELERATION

        self.speed = min(max(-PLATFORM_MAX_SPEED, self.speed), PLATFORM_MAX_SPEED)

        self.rect.x += self.speed

        if self.rect.left < 0:
            self.rect.left = 0
            self.speed = 0
        elif self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
            self.speed = 0

        rotation_factor = 1 #0.2
        rotation_angle = -self.speed * rotation_factor
        self.image = pygame.transform.rotate(self.original_image, rotation_angle)
        self.rect = self.image.get_rect(center=self.rect.center)

class Ball(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Charger l'image de la balle
        ball_image = pygame.image.load("ball.png").convert_alpha()
        # Redimensionner l'image pour qu'elle ait les dimensions de la balle
        self.image = pygame.transform.scale(ball_image, (BALL_RADIUS * 2, BALL_RADIUS * 2))
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, 0)
        self.speedx = random.choice([-BALL_SPEED_X, BALL_SPEED_X])
        self.speedy = 0

    def update(self):
        self.speedy += GRAVITY
        self.rect.x += self.speedx
        self.rect.y += self.speedy

        if self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
            self.speedx = -self.speedx

        if self.rect.top < 0:
            self.speedy = abs(self.speedy)
        elif self.rect.colliderect(platform.rect):
            if self.speedy > 0:
                self.speedy = BOUNCE_SPEED
                self.speedx = random.choice([-BALL_SPEED_X, BALL_SPEED_X])
                global score
                score += 1
        elif self.rect.top > SCREEN_HEIGHT:
            global best_score
            best_score = max(best_score, score)
            score = 0
            self.rect.center = (random.randint(0, SCREEN_WIDTH), 0)
            self.speedx = random.choice([-BALL_SPEED_X, BALL_SPEED_X])
            self.speedy = 0

    def update(self):
        self.speedy += GRAVITY
        self.rect.x += self.speedx
        self.rect.y += self.speedy

        if self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
            self.speedx = -self.speedx

        if self.rect.top < 0:
            self.speedy = abs(self.speedy)
        elif self.rect.colliderect(platform.rect):
            if self.speedy > 0:
                self.speedy = BOUNCE_SPEED  # Réinitialiser la vitesse de rebond à une valeur constante
                # Choisir aléatoirement la direction de rebond
                self.speedx = random.choice([-BALL_SPEED_X, BALL_SPEED_X])
                global score
                score += 1
        elif self.rect.top > SCREEN_HEIGHT:
            global best_score
            best_score = max(best_score, score)
            score = 0
            self.rect.center = (random.randint(0, SCREEN_WIDTH), 0)
            self.speedx = random.choice([-BALL_SPEED_X, BALL_SPEED_X])
            self.speedy = 0

all_sprites = pygame.sprite.Group()
platform = Platform()
ball = Ball()
all_sprites.add(platform, ball)

# Boucle du jeu
running = True
platform_direction = 0
score = 0
best_score = 0
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                platform_direction = -1
            elif event.key == pygame.K_RIGHT:
                platform_direction = 1
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT and platform_direction == -1:
                platform_direction = 0
            elif event.key == pygame.K_RIGHT and platform_direction == 1:
                platform_direction = 0

    platform.update(platform_direction)
    ball.update()

    window.fill(WHITE)

    all_sprites.draw(window)
    
    font = pygame.font.SysFont(None, 36)
    score_text = font.render(f"{score}", True, BLACK)
    best_score_text = font.render(f"{best_score}", True, RED)
    score_text_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 6))
    best_score_text_rect = best_score_text.get_rect(topleft=(10, 10))
    window.blit(score_text, score_text_rect)
    window.blit(best_score_text, best_score_text_rect)
    
    pygame.display.flip()

    clock.tick(FPS)